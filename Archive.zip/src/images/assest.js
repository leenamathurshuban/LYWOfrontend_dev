import liwotextlogo from "../../src/images/liwo_textlogo.png"
import cprofilelogo from "../../src/images/cp_logo.png"
import starIcon from "../../src/images/icons/star-05.svg"

export {
    liwotextlogo,
    cprofilelogo,
    starIcon
}